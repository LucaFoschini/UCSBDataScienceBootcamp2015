%% Example "Spectral clustering of a tapir"
addpath meshpart;
load meshes;

A = Tapir;
node_xy = Txy;

colors = [ 'r', 'b', 'm', 'g', 'k', 'y' ];
n = size(A, 1);
one = ones(n, 1);
degrees = A * one;

D = diag(degrees); % degree matrix
L = D - A; % combinatorial Laplacian
L = diag(degrees .^ (1/2)) * L * diag(degrees .^ (-1/2)); % normalized Laplacian

kclusters = [ 2, 3, 4, 5 ];
for i = 1 : length(kclusters)
	% defining the number of clusters
	k = kclusters(i);

	% extracting k smallest eigenpairs
	[evecs, evals, noconv] = eigs(L, k, 'sm');
	if(noconv);  error('Unable to compute eigenpairs.'); end
	
	% cluster the matrix of eigenvectors
	clusters_idx = kmeans(evecs, k);
	
	% plotting clusters
	figure;
	axis equal;
	axis off;
	hold on;
	for j = 1 : k
		cluster_idx = find(clusters_idx == j);
		set(gplotg(A(cluster_idx, cluster_idx), node_xy(cluster_idx, :), '-'), 'color', colors(j));
		hold on;
	end
	set(gcf, 'color', 'w');
	hold off;
	title(['Partitioning into ', num2str(k), ' clusters']);
end

