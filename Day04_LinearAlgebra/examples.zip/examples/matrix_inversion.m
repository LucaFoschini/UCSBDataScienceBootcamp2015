% Examples of computing left and right matrix inverses
%#ok<*MINV>
%#ok<*NOPTS>

clc;

fprintf(2, 'Example: Matrix inversion\n\n');

%% Left and right inverses
% linv(A) = left inverse of A
linv = @(A) inv(A' * A) * A';
% rinv(A) = right inverse of A
rinv = @(A) A' * inv(A * A');

%% Sample matrices
A = [ 1 2 3; 4 5 6 ];
B = A';
C = [
	1 2 3;
	2 3 1;
	3 1 2
];

%% Computing right inverse of A
clc;
fprintf(2, '"Fat" matrix A:\n');
A
fprintf(2, 'A^{-R} -- Right inverse of A (left does not exist):\n');
rinv(A)
fprintf(2, 'A * A^{-R}:\n');
A * rinv(A)
pause;

%% Computing left inverse of B
clc;
fprintf(2, '"Skinny" matrix B:\n');
B
fprintf(2, 'B^{-L} -- Left inverse of B (right does not exist):\n');
linv(B)
fprintf(2, 'B^{-L} * B:\n');
linv(B) * B
pause;

%% Computing inverse of C
clc;
fprintf(2, 'Square matrix C:\n');
C
fprintf(2, 'C^{-1} -- Inverse of C:\n');
inv(C)
fprintf(2, 'C * C^{-1}:\n');
C * inv(C)
fprintf(2, 'C^{-1} * C:\n');
inv(C) * C