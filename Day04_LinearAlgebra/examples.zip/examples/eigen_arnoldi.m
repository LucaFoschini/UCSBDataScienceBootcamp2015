%% Generating a random (symmetric, real-valued) sparse matrix

n = 5000;
pnz_per_row = 0.1;
A = sprand(n, n, pnz_per_row^2);
A = (A + A') / 2;

fprintf(2, 'Generated %d-by-%d sparse matrix with %d non-zeros.\n', n, n, nnz(A));

k = 10;

fprintf(2, 'Computing %d smallest (w.r.t. eigenvalue magnitude) eigenpairs of A... ', k);
tic;
[V, D] = eigs(A, k, 0);
fprintf(2, 'DONE in %fsec.\n', toc);
sort(diag(D))'

% You can try to compute eigenvalues using D = eig(A);
% do not forget to save your work prior to doing so, as
% the computation may take a while.
%
% fprintf(2, 'Computing eigenvalues of A using QZ algorithm... ');
% tic;
% D = eig(A);
% [~, idx] = sort(abs(D), 'ascend');
% D = D(idx);
% fprintf(2, 'DONE in %fsec.\n', toc);
% sort(D(1 : k))