%% Designing test matrix (see "eigendecomposition)
L = diag([ 1 2 3 ]); % diagonal matrix of eigenvalues
V = [1 1 1; 1 1 -2; 1 0 1]; % matrix with its columns being eigenvectors
A = V * L * V^(-1); % test matrix to find eigenpairs for

%% Solving eigenproblem directly
fprintf(2, 'Matrix A:\n');
A

% computing characteristic polynomial of A
syms lambda;
p = det(A - lambda * eye(size(A)));
fprintf(2, 'A''s characteristic polynomial p:\n');
p

% computing eigenvalues as the roots of char. poly.
eigvals = solve(p == 0, 'lambda');
fprintf(2, 'Roots of p (eigenvalues):\n');
eigvals'

% for each of the (distinct!) eigenvalues, computing the corresponding eigenspace
eigvecs = zeros(3, 3);
for i = 1 : length(eigvals)
	eigval = eigvals(i);
	eigvec = null(A - eigval * eye(size(A))); % null finds a basic of the nullspace of a matrix
	eigvecs(:, i) = eigvec;
end

fprintf(2, 'Obtained vectors:\n');
eigvecs

fprintf(2, 'True eigenpairs:\n');
diag(L)'
V

fprintf(2, 'Eigenpairs obtained by MATLAB:\n');
[v, d] = eig(A);
v
diag(d)'