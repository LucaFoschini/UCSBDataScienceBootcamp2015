% Example of eigendecomposition
function [ ] = eigendecomp()
	clc;
	fprintf(2, 'Example: Eigendecomposition\n\n');

	%% Generating a real-valued symmetric matrix A
	n = 2;
	maxval = 10;
	mu = maxval / 2;
	sigma = mu / 3;
	A = normrnd(mu, sigma, n, n);
	A = (A + A') / 2;
	fprintf(2, 'Real symmetric A:\n');
	A
	
	%% Computing eigenpairs
	[Q, L] = eig(A);

	fprintf(2, 'Eigenvectors Q:\n');
	Q
	fprintf(2, 'Eigenvalues diag(L):\n');
	diag(L)'
	fprintf(2, '$Q L Q^{-1} = \n');
	Q * L * inv(Q)
	
	%% Plotting eigenvectors
	figure;

	for i = 1 : n
		scale = L(i, i);
		vectarrow(zeros(n, 1), scale * Q(:, i));
		hold on;
	end
	hold off;
	
	%% For 2D, plotting a unit sphere transformed by A
	if(n == 2)
		xx = -1 : 0.01 : 1;
		yy = (1 - xx .^ 2) .^ (1/2);
		xx = [xx, xx(length(xx) : -1 : 1)];
		yy = [yy, -yy(length(yy) : -1 : 1)];
		stretched = A * [xx; yy];
		hold on;
		h1 = plot(xx, yy, '-b');
		hold on;
		h2 = plot(stretched(1, :), stretched(2, :), '-r');
		hold on;
		axis equal;
	end
	
	%% Adding title, labels, legend to the figure
	title('Eigenvectors of a real symmetric matrix A');
	xlabel('x_1');
	ylabel('x_2');
	if(n > 2)
		zlabel('x_3');
	end
	
	if(n == 2)
		legs = { 'unit sphere', 'unit sphere transformed by A' };
		legend([h1, h2], legs);
	end
end


%% Vector drawing (c) Rentian Xiong
% http://www.mathworks.com/matlabcentral/fileexchange/7470-plot-2d-3d-vector-with-arrow
function vectarrow(p0,p1)
%Arrowline 3-D vector plot.
%   vectarrow(p0,p1) plots a line vector with arrow pointing from point p0
%   to point p1. The function can plot both 2D and 3D vector with arrow
%   depending on the dimension of the input
%
%   Example:
%       3D vector
%       p0 = [1 2 3];   % Coordinate of the first point p0
%       p1 = [4 5 6];   % Coordinate of the second point p1
%       vectarrow(p0,p1)
%
%       2D vector
%       p0 = [1 2];     % Coordinate of the first point p0
%       p1 = [4 5];     % Coordinate of the second point p1
%       vectarrow(p0,p1)
%
%   See also Vectline

%   Rentian Xiong 4-18-05
%   $Revision: 1.0

  if max(size(p0))==3
      if max(size(p1))==3
          x0 = p0(1);
          y0 = p0(2);
          z0 = p0(3);
          x1 = p1(1);
          y1 = p1(2);
          z1 = p1(3);
          plot3([x0;x1],[y0;y1],[z0;z1]);   % Draw a line between p0 and p1
          
          p = p1-p0;
          alpha = 0.1;  % Size of arrow head relative to the length of the vector
          beta = 0.1;  % Width of the base of the arrow head relative to the length
          
          hu = [x1-alpha*(p(1)+beta*(p(2)+eps)); x1; x1-alpha*(p(1)-beta*(p(2)+eps))];
          hv = [y1-alpha*(p(2)-beta*(p(1)+eps)); y1; y1-alpha*(p(2)+beta*(p(1)+eps))];
          hw = [z1-alpha*p(3);z1;z1-alpha*p(3)];
          
          hold on
          plot3(hu(:),hv(:),hw(:))  % Plot arrow head
          grid on
          xlabel('x')
          ylabel('y')
          zlabel('z')
          hold off
      else
          error('p0 and p1 must have the same dimension')
      end
  elseif max(size(p0))==2
      if max(size(p1))==2
          x0 = p0(1);
          y0 = p0(2);
          x1 = p1(1);
          y1 = p1(2);
          plot([x0;x1],[y0;y1]);   % Draw a line between p0 and p1
          
          p = p1-p0;
          alpha = 0.1;  % Size of arrow head relative to the length of the vector
          beta = 0.1;  % Width of the base of the arrow head relative to the length
          
          hu = [x1-alpha*(p(1)+beta*(p(2)+eps)); x1; x1-alpha*(p(1)-beta*(p(2)+eps))];
          hv = [y1-alpha*(p(2)-beta*(p(1)+eps)); y1; y1-alpha*(p(2)+beta*(p(1)+eps))];
          
          hold on
          plot(hu(:),hv(:))  % Plot arrow head
          grid on
          xlabel('x')
          ylabel('y')
          hold off
      else
          error('p0 and p1 must have the same dimension')
      end
  else
      error('this function only accepts 2D or 3D vector')
  end
end
