addpath meshpart;
load meshes;
rng(2128506, 'twister');

%% Loading a graph

igraph = 1; % choose a graph, 1 to 4

if(igraph == 1)

	A = Tapir;
	node_xy = Txy;

elseif(igraph == 2)
	
	A = Eppstein;
	node_xy = Exy;

elseif(igraph == 3)
	
	A = diag(diag(Smallmesh)) - Smallmesh;
	node_xy = Sxy;
	
elseif(igraph == 4)
	
	sym = @(A) double(A + A' > 0);
	noloops = @(A) A - diag(diag(A));
	K10 = noloops(sym(double(sprand(10, 10, 0.4) > 0)));
	K10_xy = 100 * [ cos(linspace(0, 1, size(K10, 1)) .* 2 * pi)', sin(linspace(0, 1, size(K10, 1)) .* 2 * pi)' ];
	K30 = noloops(sym(double(sprand(30, 30, 0.2) > 0)));
	K30_xy = 500 + 100 * [ cos(linspace(0, 1, size(K30, 1)) .* 2 * pi)', sin(linspace(0, 1, size(K30, 1)) .* 2 * pi)' ];
	K60 = noloops(sym(double(sprand(60, 60, 0.05) > 0)));
	K60_xy = 250 + 100 * [ cos(linspace(0, 1, size(K60, 1)) .* 2 * pi)', sin(linspace(0, 1, size(K60, 1)) .* 2 * pi)' ];
	A = [
		K10, sparse(10, 90);
		sparse(60, 10), K60, sparse(60, 30);
		sparse(30, 70), K30
	];
	for e1030 = 1 : 3
		A(randi([1, 10]), randi([11, 40])) = 1;
		A(randi([11, 40]), randi([1, 10])) = 1;
	end
	for e3060 = 1 : 50
		A(randi([11, 40]), randi([41, 100])) = 1;
		A(randi([41, 100]), randi([11, 40])) = 1;
	end
	A = noloops(sym(A));
	node_xy = [ K10_xy; K60_xy; K30_xy ];
	
end

%% Preliminaries

n = size(A, 1);
one = ones(n, 1);
degrees = A * one;

%% Defining graph matrices

D = diag(degrees); % degree matrix
L = D - A; % combinatorial Laplacian
Lsym = diag(degrees .^ (1/2)) * L * diag(degrees .^ (-1/2)); % normalized Laplacian
Lrw = diag(degrees .^ (-1)) * L;

%% Performing spectral bisection using different Laplacians
for i = 1 : 3
	%% Choosing Laplacian
	if(i == 1); lap = L; elseif(i == 2); lap = Lsym; elseif(i == 3); lap = Lrw; end;
	
	%% Computing eigenpairs corresponding to two smallest eigenvalues
	[evecs, evals, noconv] = eigs(lap, 2, 'sm');
	if(noconv)
		error('Unable to compute eigenpairs.');
	end

	%% Sorting eigenpairs ascendingly w.r.t. eigenvalue magnitude
	[evals, idx] = sort(diag(evals), 'ascend');
	evecs = evecs(:, idx);

	%% Extracting Fiedler vector
	fiedler_val = evals(2);
	fiedler_vec = evecs(:, 2);
	if(fiedler_val <= eps); error('The test graph seems to be disconnected.'); end;
	
	%% Defining the first cluster based on Fiedler vector
	cluster_indicator = find(fiedler_vec >= 0);
	% cluster_indicator = find(kmeans(fiedler_vec, 2) == 1);
	
	%% Plotting the partitioned graph
	figure;
	gplotpart(A, node_xy, cluster_indicator, 'r', 'b', 'k');
	set(gcf, 'color', 'w');
	
	%% Figure's title
	if(i == 1); tt = 'Combinatorial Laplacian'; elseif(i == 2); tt = 'Normalized Laplacian'; elseif(i == 3); tt = 'Random Walk-Normalized Laplacian'; end;
	title(['Spectral bisection using \mu_2 of ', tt, ' (\lambda_2 = ', num2str(fiedler_val), ')']);
end