clc;
set(0, 'defaulttextinterpreter', 'latex');

fprintf(2, 'Example: Operator Norm\n\n');

A = [ 2 3; -2 0.5 ];
xx = -1 : 0.01 : 1;
yy = (1 - xx .^ 2) .^ (1/2);
xx = [xx, xx(length(xx) : -1 : 1)];
yy = [yy, -yy(length(yy) : -1 : 1)];

stretched = A * [xx; yy];

figure;
plot(xx, yy, '-b');
hold on;
plot(stretched(1, :), stretched(2, :), '-r');
hold on;
axis equal;

p = 2;
[max_stretch, imax_stretch] = max(bsxfun(@(x, y) (abs(x).^p + abs(y).^p) .^ (1/p), stretched(1, :), stretched(2, :)));
xx_ms = stretched(1, imax_stretch);
yy_ms = stretched(2, imax_stretch);
line([0, xx_ms], [0, yy_ms], 'LineStyle', '-', 'Color', 'g');

title(sprintf('$\\left\\|\\left[\\begin{array}{c c}%.1f&%.1f\\\\%.1f&%.1f\\end{array}\\right]\\right\\| \\approx %f$', ...
	A(1,1), A(1,2), A(2, 1), A(2, 2), max_stretch));
xlabel('x_1');
ylabel('x_2');

legend('original unit sphere', 'distorted unit sphere', 'maximal stretch');