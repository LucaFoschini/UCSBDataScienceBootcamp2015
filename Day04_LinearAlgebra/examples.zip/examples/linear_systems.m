% Example of solving linear systems using LU factorization

clc;

fprintf(2, 'Example: Solving linear systems\n\n');

fprintf(2, 'Linear system''s matrix:\n');
A = [
	3, -1;
	7, 11
]
fprintf(2, 'Linear system''s right part:\n');
b = [ 8; 32 ]
pause;

% LU = PA
fprintf(2, 'Result of LU factorization of A:\n');
[L, U, P] = lu(A)
fprintf(2, 'P'' * L * U should be quite close to A:\n')
P'' * L * U
pause;

%% Solving the system

% Applying permutation P to the right part of the system:
% b1 = P^{-1} b = P^T * b (for permutation matrices, inversion = transposition)
b1 = P' * b;

% Forward substitution (generally, y = L \ b1)
y = zeros(2, 1);
y(1) = b1(1);
y(2) = b1(2) - L(2, 1) * y(1);
fprintf('y = L \\ (P'' * b)\n');
y

% Back substitution (generally, x = U \ y)
x = zeros(2, 1);
x(2) = y(2) / U(2, 2);
x(1) = (y(1) - U(1, 2) * x(2)) / U(1, 1);
fprintf('x = U \\ y\n');
x

% Checking solution
fprintf(2, 'Solution obtained by MATLAB (A \\ b):\n');
A \ b